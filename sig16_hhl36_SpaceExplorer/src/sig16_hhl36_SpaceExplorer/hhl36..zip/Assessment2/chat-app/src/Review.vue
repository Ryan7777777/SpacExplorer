<template>
  <div>
    <div v-if="login === 'true'">
      <ul>
        <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
      <li><router-link :to="{ name: 'addvenue' }" > Addedvenue </router-link></li>
      <li><router-link :to="{name: 'me',params:{userId:id}}"> Current user:{{username}}</router-link></li>
        <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
      </ul>
    </div>
    <div v-else>
      <ul>
        <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
      <li><router-link :to="{ name: 'login' }" > Login </router-link></li>
      <li><router-link :to="{ name: 'register' }" > Register </router-link></li>
      </ul>
    </div>
  <table>
  <th style="width: 20%">Review</th>
  <th style="width: 10%">Review Auther</th>
  <th style="width: 10%">Star Rateing</th>
  <th style="width: 10%">Cost Rating</th>
  <th style="width: 10%">Post Time</th>
    <th atyle="width: 40%"></th>
  <tr v-for="review in filteredcity">
      <td>{{review.reviewBody}}</td>
      <td>{{review.reviewAuthor.username}}</td>
      <td>{{review.starRating}}</td>
      <td>{{costslist[review.costRating].sign}}</td>
      <td>{{review.timePosted}}</td>
  </tr>
  </table>
    <a>Page:</a>
    <select v-model="batchpage" >
      <option v-for="batch in bachesls" v-bind:value="{batch}">{{batch}}</option>
    </select>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        reviews: [],
        batches:1,
        bachesls:[],
        batchpage:"1",
        costslist:[{"rate":0,"sign":"Free"},{"rate":1,"sign":"$"},{"rate":2,"sign":"$$"},{"rate":3,"sign":"$$$"},{"rate":4,"sign":"$$$$"}],
        login:"",
        auth:false,
        id:"",
        username :""
      }
    },
    mounted: function () {
      this.getRview();
      this.getlogindata();
    },
    methods: {
      getlogindata: function(){
        this.login = localStorage.login
        this.auth = localStorage.auth
        this.id = localStorage.userId
        if(this.id !=undefined){
          this.getuser();
        }
      },
      getuser: function() {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
          });
      },
      getRview: function () {
        localStorage.name = "1111"
        this.$http.get('http://127.0.0.1:4941/api/v1/venues/' + this.$route.params.venueId + '/reviews')
          .then(function (response) {
            this.reviews = response.data;
            this.getbatches();
          }, function (error) {
            this.error = error;
            this.errorFlag = false;
          });

      },
      getbatches: function(){
        this.batches = Math.ceil(this.reviews.length/10);
        for (var i =1; i<=this.batches ;i++){
          this.bachesls.push(i)
        }
      }
    },

    computed: {
      filteredcity: function () {
        var current_review = this.reviews;
        current_review = current_review.slice().sort((a, b) => (Date.parse(a.timePosted)) + (Date.parse(b.timePosted)))
        if(this.batchpage === "1"){}else{
          var lower = this.batchpage.batch *10 -10;
          if(this.batchpage.batch *10 > this.venues.length){
            var upper = this.venues.length;
          } else {
            var upper = this.batchpage.batch *10-1}
          current_review = current_review.slice(lower,upper);
        }
        return current_review;
      }
    }
  }
</script>
<style>
  td{
    text-align: left;
    height: 20px;
  }
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }

  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }
  table{
    border-collapse: collapse;
  }
 th{
   background-color: gray;
   padding-left: 5px;
   padding-top: 20px;
   paddign-bottom: 20px;
 }
  td{
    padding-top: 20px;
    padding-left: 70px;
  }
</style>
