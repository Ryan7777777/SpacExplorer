<template>
    <div>
      <ul>
        <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
        <li><router-link :to="{name: 'me',params:{userId:id}}"> Current user:{{username}}</router-link></li>
        <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
      </ul>
      <br>
      <h3 style="padding-left: 2px">Post  review:</h3>
      <br>
      <a>Review</a>
      <br>
      <tr><input v-model = "review" placeholder = "Review details"  type="text" required></tr>
      <a>Star Rating</a>
      <tr><select v-model="costselect" >
      <option v-for="cost in costslist" v-bind:value="{cost}">{{cost.sign}}</option>
      </select></tr>
      <a>Cost Ratring</a><br>
      <select v-model="starselect" >
        <option v-for="cost in starlist" v-bind:value="{cost}">{{cost.sign}}</option>
      </select>
      <br>
      <br>
      <button type = "button" class = "btn btn-primary" data-dismiss = "modal"
              v-on:click = "postreview">
        Post Review
      </button>

    </div>
</template>

<script>
  export default {
    data() {
      return {
        loginc:false,
        auth:"",
        id:"",
        uservenue:[],
        reviews: '',
        costslist:[{"rate":0,"sign":"Free"},{"rate":1,"sign":"$"},{"rate":2,"sign":"$$"},{"rate":3,"sign":"$$$"},{"rate":4,"sign":"$$$$"}],
        starlist:[{"rate":1,"sign":"1"},{"rate":2,"sign":"2"},{"rate":3,"sign":"3"},{"rate":4,"sign":"4"},{"rate":5,"sign":"5"}],
        costselect:"",
        starselect:"",
        username :""
      }
    },
    mounted: function () {
      this.getlogindata();
      this.getreview();
    },
    methods: {
      getlogindata: function () {
        this.loginc = localStorage.login;
        this.auth = localStorage.auth;
        this.id = localStorage.userId;
        if (this.loginc === undefined) {
          alert("Please log in");
          this.$router.push('/login');
        } else{
          var retreceddeta = localStorage.getItem("venue");
          var uservenues = JSON.parse(retreceddeta)
          this.uservenue = uservenues;
          var venueid = (this.$route.params.venueId).toString()
          if(uservenues.includes(venueid)){
            alert("Venue Admin can not post a review");
            this.$router.push('/');
          }
          if(this.id !=undefined){
            this.getuser();
          }
        }
      },
      getreview: function(){
        this.$http.get('http://127.0.0.1:4941/api/v1/venues/' + this.$route.params.venueId + '/reviews')
          .then(function (response) {
            this.reviews = response.data;
            this.checkreview();
          }, function (error) {
            this.error = error;
            this.errorFlag = false;
          });
      },
      checkreview: function() {
        var review = this.reviews
        var userid = this.id
        for (var i = 0; i < review.length; i++) {
          console.log(review[i])
          if ((review[i].reviewAuthor.userId == userid)) {
            alert("Cannot have multiple review in same venue")
            this.$router.push('/')
          }

        }
      },
        postreview: function(){
         this.$http.post('http://127.0.0.1:4941/api/v1/venues/'+ this.$route.params.venueId +'/reviews',{
           reviewBody:this.review,
           costRating: this.costselect.cost.rate,
           starRating: this.starselect.cost.rate
         },{headers: {'X-Authorization': this.auth}})
           .then(function (response) {
             this.$router.push('/');
           }, function (error) {
             alert(error.statusText);
           });
        },
      getuser: function() {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
          });
      },
    },

    computed: {}
  }
</script>

<style scoped>
 select{
   width: 180px;
 }
  input{
    width: 176px;
  }
  button{
    passing-left: 600px;
  }
 ul {
   list-style-type: none;
   margin: 0;
   padding: 0;
   overflow: hidden;
   background-color: #333;
 }
 button{
   position: absolute;,
 bottom:0px;
 }
 li {
   float: left;
 }

 li a {
   display: block;
   color: white;
   text-align: center;
   padding: 14px 16px;
   text-decoration: none;
 }
 li a:hover {
   background-color: #222;
 }

</style>
