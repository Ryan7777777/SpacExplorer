<template>
  <div v-if="login === 'false'">
  </div>
  <div v-else>
    <div v-if = "errorFlag" style = " color : red ; ">
      {{ error }}
    </div>
    <ul>
      <li><router-link :to="{ name: 'home' }" > All venue </router-link></li>
      <li><router-link :to="{ name: 'addvenue' }" > Addedvenue </router-link></li>
      <li><router-link :to="{name: 'me',params:{userId:id}}">Current user : {{username}}</router-link></li>
      <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
    </ul>
    <div style=" width: 100%;background-color: #8A8A8A;">
      <br>
      <a style="font-size: 40px; padding-bottom:100px">MY venues</a>
      <br>
      <br>
      <a>Search by venuen name</a>
      <input type="text" v-model="search" placeholder="Search venune.." style="width: 150px"/>
      <a>Filted by city</a>
      <select v-model="selected" style="width: 150px">
        <option v-for="city in cities" v-bind:value="{city}">{{city}}</option>
      </select>
      <a>Filted by category</a>
      <select v-model="selectcat" style="width: 150px">
        <option v-for="cat in categoryname" v-bind:value="{cat}">{{cat.categoryName}}</option>
      </select>
      <a>Filter by Cost rate</a>
      <select v-model="costselect" style="width: 150px">
        <option v-for="cost in costslist" v-bind:value="{cost}">{{cost.sign}}</option>
      </select>
      <a>Filter by Star rate</a>
      <select v-model="starselect" style="width: 150px">
        <option v-for="cost in starlist" v-bind:value="{cost}">{{cost.sign}}</option>
      </select>
      <div class="sort">
        <br>
        <a style=" padding-right: 30px;">Sorting by Start Rating</a>
        <a>Sorting by Cost Rating</a></br>
        <label style=" padding-right: 70px;"><input type="radio" v-model="sortstar" value="High" /> High to Low</label>
        <label><input type="radio" v-model="sortcost" value="High" /> High to Low</label></br>
        <label style=" padding-right: 70px;"><input type="radio" v-model="sortstar" value="Low" /> Low to High</label>
        <label><input type="radio" v-model="sortcost" value="Low" /> Low to High</label></br>
      </div>
    </div>
      <table>
        <th style="width: 10%"> Venue name </th>
        <th style="width: 10%">Category</th>
        <th style="width: 10%">Stat Rating</th>
        <th style="width: 10%">Cost Rating</th>
        <th style="width: 30%"></th>
        <th style="width: 10%"></th>
        <th style="width: 10%"></th>
        <th style="width: 10%"></th>
        <th style="width: 10%"></th>
        <tr v-for = "venue in filteredcity">
          <td>{{venue.venueName}}</td>
          <td>{{categoryname[venue.categoryId-1].categoryName}}</td>
          <td>{{venue.meanStarRating}}</td>
          <td>{{venue.modeCostRating}}</td>
          <td>
          </td>
          <td><button style="margin:10px; width:100px"><router-link :to="{name:'venue',params:{venueId:venue.venueId}}" style='text-decoration:none; color: black'>View</router-link></button></td>
          <td><button style="margin:10px; width:100px"><router-link  :to="{name:'review',params:{venueId:venue.venueId}}"style='text-decoration:none; color: black'>Review</router-link></button></td>
          <td><button style="margin:10px; width:100px"><router-link :to="{name:'updatevenue',params:{venueId:venue.venueId}}"style='text-decoration:none; color: black' >Update Venue</router-link></button></td>
        </tr>


      </table>
      <a>Page:</a>
      <select v-model="batchpage" >
        <option v-for="batch in bachesls" v-bind:value="{batch}">{{batch}}</option>
      </select>

  </div>
</template>


<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        venues: [],
        cities: ["All", "None "],
        selected: 'All',
        categoryname:[],
        photos: [],
        length: "",
        search: "",
        selectcat: null,
        sortstar:"High",
        sortcost:null,
        costslist:[{"rate":0,"sign":"Free"},{"rate":1,"sign":"$"},{"rate":2,"sign":"$$"},{"rate":3,"sign":"$$$"},{"rate":4,"sign":"$$$$"}],
        costselect:"no select",
        starlist:[{"rate":1,"sign":"1"},{"rate":2,"sign":"2"},{"rate":3,"sign":"3"},{"rate":4,"sign":"4"},{"rate":5,"sign":"5"}],
        starselect:"no select",
        batches:1,
        bachesls:[],
        batchpage:"1",
        longdesc: false,
        login:"",
        auth:"",
        id:"",
        venuename:"",
        uservenue:[],
        venuenecater:[],
        venuecat:{cat:{ "categoryId": 0, "categoryName": "All"}},
        venuee:[],
        venueaddress:"",
        venuesd:"",
        venuecity:"",
        venuelat:"",
        venuelong:"",
        venueld:"",
        username :""
      }
    },
    mounted: function () {
      this.getlogindata();
      this.getVenues();
      this.getCategories();
    },
    methods: {
      getVenues: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/venues')
          .then(function (response) {
            this.venues = response.data;
            this.venuee = response.data;
            this.uniqueVenue();
            this.filtermyvenue();
            this.getphoto();
            this.getbatches();
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getlogindata: function() {
        this.login = localStorage.login
        this.auth = localStorage.auth
        this.id = localStorage.userId
        var retreceddeta = localStorage.getItem("venue");
        var uservenues = JSON.parse(retreceddeta)
        this.uservenue = uservenues;
        if(this.id !=undefined){
          this.getuser();
        }
        if (this.login === undefined) {
          alert("Please log in");
          this.$router.push('/login');
        }
      },
      getuser: function() {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
          });
      },
      getCategories: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/categories')
          .then(function (response) {
            this.venuenecater = response.data;
            var num = Object.assign({}, response.data, {"a":{ "categoryId": 0, "categoryName": "All"}});
            this.categoryname = num;
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getphoto: function () {
        var venue_id = [];
        for (var i = 0; i < this.venues.length; i++) {
          if (venue_id.includes(this.venues[i].venueId)) {
          } else {
            venue_id.push(this.venues[i].venueId);
          }
        }
        for (var i = 0; i < venue_id.length; i++) {
          this.$http.get('http://127.0.0.1:4941/api/v1/venues/' + venue_id[i])
            .then(function (response) {
              this.photos[response.url.split("/").pop()] = response.data;
              this.photos.push( response.data);
              this.test = response.data
            }, function (error) {
              this.error = error;
              this.errorFlag = true;
            });
        }

      },
      uniqueVenue: function () {
        for (var i = 0; i < this.venues.length; i++) {
          if (this.cities.includes(this.venues[i].city)) {
          } else {
            this.cities.push(this.venues[i].city)
          }
        }
      },
      getbatches: function(){
        this.batches = Math.ceil(this.venues.length/10);
        for (var i =1; i<=this.batches ;i++){
          this.bachesls.push(i)
        }
      },
      filtermyvenue: function(){
        var current_venues = this.venues;
        var user = this.uservenue
        var array = []
        var current = ""
        for(var i=0;i<user.length;i++){
          current  = current_venues.filter(venue => venue.venueId == user[i])
          array.push(current[0])
        }
        this.venues = array
      }
    },
    computed: {
      filteredcity: function () {
        var current_venues = this.venues;
        for(var i=0 ; i<current_venues.length;i++){
          if(current_venues[i].meanStarRating === null) {
            current_venues[i].meanStarRating = 3
          }
          if(current_venues[i].modeCostRating === null){
            current_venues[i].modeCostRating = 0
          }
        }
        if(this.batchpage === "1"){}else{
          var lower = this.batchpage.batch *10 -10;
          if(this.batchpage.batch *10 > this.venues.length){
            var upper = this.venues.length;
          } else {
            var upper = this.batchpage.batch *10-1}
          current_venues = current_venues.slice(lower,upper);
        }
        if(this.selectcat == null || this.selectcat === "All" ) {
          current_venues = current_venues
        } else {
          var selectcat = this.selectcat;
          if (selectcat.cat.categoryId === 0) {
            current_venues = current_venues
          } else {
            current_venues = current_venues.filter(venue => venue.categoryId === selectcat.cat.categoryId)
          }
        }
        if (this.search === "") {}else{
          var search = this.search;
          current_venues = current_venues.filter(venue => venue.venueName.toLowerCase().includes(search.toLowerCase()))
        }if(this.selected === "All" || this.selected.city == 'All'){}else{
          var selectcity = this.selected.city;
          current_venues = current_venues .filter(venue => venue.city === selectcity)
        }
        if (this.sortstar == "High"){
          current_venues = current_venues.slice().sort((a, b) => (a.meanStarRating) + (b.meanStarRating))
        }else{
          current_venues = current_venues.slice().sort((a, b) => (a.meanStarRating) - (b.meanStarRating))
        }
        if (this.sortcost == null) {}else if(this.sortcost == "High"){
          current_venues = current_venues.slice().sort((a, b) => (a.modeCostRating) + (b.modeCostRating))
        } else {
          current_venues = current_venues.slice().sort((a, b) => (a.modeCostRating) - (b.modeCostRating))
        }
        if(this.costselect === "no select"){}else{
          current_venues = current_venues .filter(venue => this.costselect.cost.rate <=venue.modeCostRating )
        }
        if(this.starselect === "no select"){}else{
          current_venues = current_venues .filter(venue => venue.meanStarRating >= this.starselect.cost.rate)
        }
        return current_venues;
      }
    }
  }
</script>

<style scoped>
  h1{
    padding:0px;
    background: darkgray;
  }
  img{
    width: 100%;
    height:auto;
    display: block
  }
  td{
    text-align: left;
    height: 20px;
  }
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  button{
    position: absolute;,
  bottom:0px;
  }
  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }
  table {
    border-collapse: collapse;
    table-layout: fixed;
    font-falimy: Arial;

  }
  th{
     background-color: gray;
   }
  td{
    padding-left: 40px;
  }
</style>
