<template>
  <div>
    <tr><router-link :to="{ name: 'home' }" > Home </router-link></tr>
    <a>Given name:</a>
    <input v-model = "givenname" type="text" required><br>
    <a>Family name:</a>
    <input v-model = "familyname" type="text" required><br>
    <a>Current Password:</a>
    <input v-model = "currentpassword" type="password" required><br>
    <a>New Password:</a>
    <input v-model ="newpassword" type="password" required><br>
    <button type = "button" class = "btn btn-primary" data-dismiss = "modal"
            v-on:click = "edituser">
      Update User
    </button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        givenname: "",
        familyname: "",
        password: "",
        newpassword:"",
        currentpassword:"",
        loginc: "",
        auth: "",
        id: "",
        searchid: ""
      }
    },
    mounted: function () {
      this.getlogindata();
      this.getuser();
    },
    methods: {
      getlogindata: function () {
        this.loginc = localStorage.login;
        this.auth = localStorage.auth;
        this.searchid = localStorage.userId;
        this.id = this.$route.params.userId;
        this.password = localStorage.password;
        if(this.id != this.searchid){
          this.$router.push('/');
        }
      },
      getuser: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
            this.givenname = resopnse.data.givenName
            this.familyname = resopnse.data.familyName
          });
      },
      edituser: function () {
        if(this.givenname == ""| this.familyname == "" || this.currentpassword == ""|| this.newpassword == ""){
          alert("Please enter you profile")
        } else {
          var password = this.password
          if (this.password == this.currentpassword) {
            this.$http.patch('http://127.0.0.1:4941/api/v1/users/' + this.id, {
              givenName: this.givenname,
              familyName: this.familyname,
              password: this.newpassword
            }, {headers: {'X-Authorization': this.auth}})
              .then(function (response) {
                localStorage.password = password
                this.$router.push('/');
              }, function (error) {
                alert(error.statusText);
              });
          } else {
            alert("Wrong current password");
          }
        }
      }
    },
    computed: {}
  }
</script>

<style scoped>

</style>
