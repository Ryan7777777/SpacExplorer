<template>
  <div v-if="loginc === 'false'">
    <a>User already login</a>
  </div>
  <div v-else>

  </div>
</template>


<script>
  export default {
    data() {
      return {
        loginc:false,
        auth:"",
        id:""
      }
    },
    mounted: function () {
      this.getlogindata();
    },
    methods: {
      getlogindata: function () {
        this.loginc = localStorage.login;
        this.auth = localStorage.auth;
        this.id = localStorage.userId;
        if (this.loginc === 'false') {
          alert("Please log in");
          this.$router.push('/login');
        } else{
          this.logout();
        }
      },
      logout: function(){
        this.$http.post('http://127.0.0.1:4941/api/v1/users/logout',{},{headers:{'X-Authorization' :this.auth}})
          .then(function (response) {
            this.$router.push('/');
            localStorage.login = false;
            localStorage.clear();
          }, function (error) {
            alert(error.statusText);
            this.error = true;
            this.errormessage = error.statusText;
          });
      }
    },
    computed: {}
  }
</script>

<style scoped>

</style>
