<template>
  <div>
      <div v-if = "errorFlag" style = " color : red ; ">
    {{ error }}
  </div>
    <div v-if="login === 'true'">
      <ul>
        <li><router-link :to="{ name: 'venueadmin' }" > Your venue </router-link></li>
        <li><router-link :to="{ name: 'addvenue' }" > Addedvenue </router-link></li>
        <li><router-link :to="{name: 'me',params:{userId:id}}">Current user : {{username}}</router-link></li>
        <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
      </ul>
    </div>
    <div v-else>
      <ul>
        <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
        <li><router-link :to="{ name: 'login' }" > Login </router-link></li>
        <li><router-link :to="{ name: 'register' }" > Register </router-link></li>
      </ul>
    </div>

    <div v-if="$route.path === '/venueadmin'">
      <tr><router-link :to="{ name: 'home' }" > All venue </router-link></tr>
    </div>
    <div v-else>
      <div style=" width: 100%;background-color: #8A8A8A;">
        <br>
      <a>Search by venuen name</a>
      <input type="text" v-model="search" placeholder="Search venune.."/>
      <a>Filted by city</a>
      <select v-model="selected" style="width: 150px">
        <option v-for="city in cities" v-bind:value="{city}">{{city}}</option>
      </select>
      <a>Filted by category</a>
      <select v-model="selectcat " style="width: 150px">
        <option v-for="cat in categoryname" v-bind:value="{cat}">{{cat.categoryName}}</option>
      </select>
      <a>Filter by Cost rate</a>
      <select v-model="costselect" style="width: 150px" >
        <option v-for="cost in costslist" v-bind:value="{cost}">{{cost.sign}}</option>
      </select>
      <a>Filter by Star rate</a>
      <select v-model="starselect" style="width: 150px" >
        <option v-for="cost in starlist" v-bind:value="{cost}">{{cost.sign}}</option>
      </select>
        <br>
      <div class="sort">
        <a style=" padding-right: 30px;">Sorting by Start Rating</a>
        <a>Sorting by Cost Rating</a><br>
        <label style=" padding-right: 70px;"><input type="radio" v-model="sortstar" value="High" /> High to Low</label>
        <label><input type="radio" v-model="sortcost" value="High" /> High to Low</label><br>
        <label style=" padding-right: 70px;"><input type="radio" v-model="sortstar" value="Low" /> Low to High</label>
        <label ><input type="radio" v-model="sortcost" value="Low" /> Low to High</label></br>
      </div>
      </div>
      <table>
        <th style="width: 12%"> Venue name </th>
        <th style="width: 12%">Category</th>
        <th style="width: 12%">Stat Rating</th>
        <th style="width: 12%">Cost Rating</th>
        <th style="width: 22%">Photos</th>
        <th style="width: 10%"></th>
        <th style="width: 10%"></th>
        <th style="width: 10%"></th>
        <tr v-for = "venue in filteredcity">
          <td>{{venue.venueName}}</td>
          <td>{{categoryname[venue.categoryId-1].categoryName}}</td>
          <td>{{venue.meanStarRating}}</td>
          <td>{{venue.modeCostRating}}</td>
          <template v-if="venue.primaryPhoto == null">
            <td>{{photo(0,0)}}</td>
          </template>
          <template v-else>
              <a>{{photo(venue.venueId,venue.primaryPhoto)}}</a>
              <img :src="src" alt="">
          </template>
          <td><button style="margin:10px"><router-link :to="{name:'venue',params:{venueId:venue.venueId}}"style='text-decoration:none; color: black'>View</router-link></button></td>
          <td><button style="margin:10px"><router-link :to="{name:'review',params:{venueId:venue.venueId}}"style='text-decoration:none; color: black'>Review</router-link></button></td>
            <td><button style="margin:10px"><router-link :to="{name:'postreview',params:{venueId:venue.venueId}}"style='text-decoration:none; color: black'>Write a review</router-link></button></td>`
        </tr>
      </table>

      <a>Page:</a>
      <select v-model="batchpage" >
        <option v-for="batch in bachesls" v-bind:value="{batch}">{{batch}}</option>
      </select>
    </div>
  </div>
    </div>


</template>
<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        venues: [],
        cities: ["All", "None "],
        selected: 'All',
        categoryname:[],
        photos: [],
        length: "",
        search: "",
        selectcat: null,
        sortstar:"High",
        sortcost:null,
        costslist:[{"rate":0,"sign":"Free"},{"rate":1,"sign":"$"},{"rate":2,"sign":"$$"},{"rate":3,"sign":"$$$"},{"rate":4,"sign":"$$$$"}],
        costselect:"no select",
        starlist:[{"rate":1,"sign":"1"},{"rate":2,"sign":"2"},{"rate":3,"sign":"3"},{"rate":4,"sign":"4"},{"rate":5,"sign":"5"}],
        starselect:"no select",
        batches:1,
        bachesls:[],
        batchpage:"1",
        longdesc: false,
        login:false,
        auth:"",
        id:"",
        detial:[],
        username :"",
        src: ""
      }
    },
    mounted: function () {
      this.getVenues();
      this.getlogindata();
      this.getCategories();
    },
    methods: {
      getVenues: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/venues')
          .then(function (response) {
            this.venues = response.data;
            this.uniqueVenue();
            this.getphoto();
            this.getbatches();
            this.getsign();
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getlogindata: function () {
        this.login = localStorage.login
        this.auth = localStorage.auth
        this.id = localStorage.userId
        if (this.id != undefined) {
          this.getuser();
        }
      },
      getuser: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
          });
      },
      getCategories: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/categories')
          .then(function (response) {
            var num = Object.assign({}, response.data, {"a": {"categoryId": 0, "categoryName": "All"}});
            this.categoryname = num;
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getphoto: function () {
        var uuservenues = []
        var venue_id = [];
        for (var i = 0; i < this.venues.length; i++) {
          if (venue_id.includes(this.venues[i].venueId)) {
          } else {
            venue_id.push(this.venues[i].venueId);
          }
        }
        for (var i = 0; i < venue_id.length; i++) {
          this.$http.get('http://127.0.0.1:4941/api/v1/venues/' + venue_id[i])
            .then(function (response) {
              this.photos[response.url.split("/").pop()] = response.data;
              this.photos.push(response.data);
              if (response.data.admin.userId == localStorage.userId) {
                uuservenues.push(response.url.split("/").pop());
              } else {
              }
              var myjson = JSON.stringify(uuservenues)
              localStorage.venue = myjson
              this.test = response.data
            }, function (error) {
              this.error = error;
              this.errorFlag = true;
            });
        }
      },
      uniqueVenue: function () {
        for (var i = 0; i < this.venues.length; i++) {
          if (this.cities.includes(this.venues[i].city)) {
          } else {
            this.cities.push(this.venues[i].city)
          }
        }
      },
      getbatches: function () {
        this.batches = Math.ceil(this.venues.length / 10);
        for (var i = 1; i <= this.batches; i++) {
          this.bachesls.push(i)
        }
      },
      getsign: function () {
        var current_venues = this.venues;
        for (var i = 0; i < current_venues.length; i++) {
          if (current_venues[i].meanStarRating === null) {
            current_venues[i].meanStarRating = 3
          }
          if (current_venues[i].modeCostRating === null) {
            current_venues[i].modeCostRating = 0
          }
        }
        this.venues = current_venues
      },
      photo:function(id,filename) {
        if (id === 0 && filename == 0) {
          return "no photo for this venues";
        } else {
          if (this.photos[id].photos === undefined) {
          } else {
            this.$http.get("http://127.0.0.1:4941/api/v1/venues/" + id + "/photos/" + filename, {responseType: 'blob'})
              .then(function (rep) {
                  let reader = new FileReader();
                  reader.readAsDataURL(rep.data);
                  reader.onload = () => {
                    this.src = reader.result;
                  }
                });
          }
        }
      }
    },
    computed: {
      filteredcity: function () {
        var current_venues = this.venues;
        if(this.batchpage === "1"){}else{
          var lower = this.batchpage.batch *10 -10;
          if(this.batchpage.batch *10 > this.venues.length){
            var upper = this.venues.length;
          } else {
            var upper = this.batchpage.batch *10-1}
          current_venues = current_venues.slice(lower,upper);
        }
        if(this.selectcat == null || this.selectcat === "All" ) {
          current_venues = current_venues
        } else {
          var selectcat = this.selectcat;
          if (selectcat.cat.categoryId === 0) {
            current_venues = current_venues
          } else {
            current_venues = current_venues.filter(venue => venue.categoryId === selectcat.cat.categoryId)
          }
        }
        if (this.search === "") {}else{
          var search = this.search;
          current_venues = current_venues.filter(venue => venue.venueName.toLowerCase().includes(search.toLowerCase()))
        }if(this.selected === "All" || this.selected.city == 'All'){}else{
          var selectcity = this.selected.city;
          current_venues = current_venues .filter(venue => venue.city === selectcity)
        }
        if (this.sortstar == "High"){
          current_venues = current_venues.slice().sort((a, b) => (a.meanStarRating) + (b.meanStarRating))
        }else{
          current_venues = current_venues.slice().sort((a, b) => (a.meanStarRating) - (b.meanStarRating))
        }
        if (this.sortcost == null) {}else if(this.sortcost == "High"){
          current_venues = current_venues.slice().sort((a, b) => (a.modeCostRating) + (b.modeCostRating))
        } else {
          current_venues = current_venues.slice().sort((a, b) => (a.modeCostRating) - (b.modeCostRating))
        }
        if(this.costselect === "no select"){}else{
          current_venues = current_venues.filter(venue =>   this.costselect.cost.rate <= venue.modeCostRating)
        }
        if(this.starselect === "no select"){}else{
          current_venues = current_venues.filter(venue => venue.meanStarRating >= this.starselect.cost.rate)
        }
        return current_venues;
      }
    }
  }
</script>
<style>
  c{
    float:right;
  }
  table {
    border-collapse: collapse;
    table-layout: fixed;
    font-falimy: Arial;
    wdith: 100%
  }
  table th{

    height: 10px;
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #8C8888;
    color: white;
  }

  img{
    width: 40%;
    height:auto;
    display: block
  }
  td{
    text-align: left;
    height: 60px;
  }
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
button{
  position: absolute;,
  bottom:0px;
}
  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }
  button {
   width:150px;
    heihgt:100px;
  }
  th{
    padding-left: 40px;
  }
  td{
    padding-top: 10px;
    padding-bottom: 5px;
    padding-left: 40px;
  }
</style>0
