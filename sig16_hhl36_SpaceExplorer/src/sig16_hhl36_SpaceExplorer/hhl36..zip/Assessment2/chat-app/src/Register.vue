<template>
  <div>
    <div v-if="loginc === 'true'">
      <a>User already login</a>
    </div>
    <div v-else>
      <ul>
      <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
      </ul>
      <div style="background-color: gray; padding-bottom: 20px">
        <br>
    <a style="font-size: 20px; padding-top: 20px">Register</a>
      </div>
        <br>
      <td>Given name</td>
      <input v-model = "givename" placeholder = "Given name"  type="text" >
      <td> Family name</td>
      <input v-model = "familyname" placeholder = "Family name"  type="text" >
      <td> Username</td>
      <input v-model = "username" placeholder = "User name"  type="text" >
      <td>Email Address </td>
      <input v-model = "emailaddress" placeholder = "Email address"  type="e-mail" >
      <td>Password</td>
      <input v-model = "password" placeholder = "Password"  type="password" >
      <td>Confrim Password</td>
      <input v-model ="confirmpw" placeholder = "Password"  type="password" >
      <br>
      <br>
    <button type = "button" class = "btn btn-primary" data-dismiss = "modal"
            v-on:click = "checkinput">
      Register
    </button>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        givename:"",
        familyname:"",
        username:"",
        emailaddress:"",
        password:"",
        confirmpw:"",
        error: false,
        errormessage:"",
        token:"",
        loginc:false,
        auth:"",
        id:""
      }
    },
    mounted: function () {
      this.getlogindata();
    },
    methods: {
      getlogindata: function(){
        this.loginc = localStorage.login;
        this.auth = localStorage.auth;
        this.id = localStorage.userId;
        if(this.loginc === 'true'){
          alert("User already log in");
          this.$router.push ( '/' );
        }
      },
      checkinput: function () {
        var reuse = /^[a-zA-Z0-9]+$/;
        var re = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        if (reuse.test(this.username) == false || this.username.length > 64) {
          alert("Please have a username up to 64 characters")
        } else if (re.test(this.emailaddress) == false) {
          alert("Please have a valid e-mail address")
        } else if (this.password != this.confirmpw) {
          alert("Please make sure your password and confirmed password is identical")
        } else {
          this.$http.post('http://127.0.0.1:4941/api/v1/users',
            {
              email: this.emailaddress,
              username: this.username,
              givenName: this.givename,
              familyName: this.familyname,
              password: this.password
            })
            .then(function (response) {
              this.login()
            }, function (error) {
              alert(error.statusText);
              this.error = true;
              this.errormessage = error.statusText;
            });
        }
      },
      login: function(){
        var pw = this.password
        this.$http.post('http://127.0.0.1:4941/api/v1/users/login',
          {
            email: this.emailaddress,
            username: this.username,
            password: this.password
          })
          .then(function (response) {
            localStorage.userId = response.body.userId;
            localStorage.auth = response.body.token;
            localStorage.login = true;
            localStorage.password = pw
            this . $router . push ( '/' );
          }, function (error) {
            alert(error.statusText);
            this.error = true;
            this.errormessage = error.statusText;
          });
      }
    },
    computed: {
      }
    }
</script>
<style>
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  button{
    position: absolute;,
  bottom:0px;
  }
  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }
</style>

