<template>
  <div v-if= "$route.params.venueId">
    <td>Current venue name</td>
    <tr><input v-model = "venuename" type="text" required></tr>
    <a>Current category</a>
    <tr><select v-model="venuecat">
      <option v-for="cat in venuenecater" v-bind:value="{cat}">{{cat.categoryName}}</option>
    </select></tr>
    <a>Current address</a>
    <tr><input v-model = "venueaddress" type="text" required></tr>
    <a>Current short description</a>
    <tr><input v-model = "venuesd" type="text" required></tr>
    <a>Current long description</a>
    <tr><input v-model = "venueld" type="text" required></tr>
    <a>Current city</a>
    <tr><input v-model = "venuecity" type="text" required></tr>
    <a>Current latitude</a>
    <tr><input v-model = "venuelat" type="text" required></tr>
    <a>Current longitude</a>
    <tr><input v-model = "venuelong" type="text" required></tr>
    <button type = "button" class = "btn btn-primary" data-dismiss = "modal"
            v-on:click = "updatevenue">
      UpdateVenue
    </button>

  </div>
</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        venues: [],
        cities: ["All", "None "],
        login:"",
        auth:"",
        id:"",
        venuename:"",
        uservenue:[],
        venuenecater:[],
        venuecat:{cat:{ "categoryId": 0, "categoryName": "All"}},
        venuee:[],
        venueaddress:"",
        venuesd:"",
        venuecity:"",
        venuelat:"",
        venuelong:"",
        venueld:"",
        vid:"",
      }
    },
    mounted: function () {
      this.getlogindata();
      this.getVenues();
      this.getCategories();
    },
    methods: {
      getVenues: function () {
          this.$http.get('http://127.0.0.1:4941/api/v1/venues')
            .then(function (response) {
              this.venues = response.data;
              this.venuee = response.data;
              if (this.$route.params.venueId === undefined) {
              } else {
                for (var i = 0; i < this.venuee.length; i++) {
                  if (this.venuee[i].venueId == this.$route.params.venueId) {
                    this.venuename = this.venuee[i].venueName;
                    this.venuesd = this.venuee[i].shortDescription;
                    this.venuecity = this.venuee[i].city;
                    this.venuelat = this.venuee[i].latitude;
                    this.venuelong = this.venuee[i].longitude;
                  }
                }
              }
              this.getphoto();
            }, function (error) {
              this.error = error;
              this.errorFlag = true;
            });
      },
      getlogindata: function () {
        this.login = localStorage.login
        this.auth = localStorage.auth
        this.vid = localStorage.userId
        var retreceddeta = localStorage.getItem("venue");
        var uservenues = JSON.parse(retreceddeta)
        this.uservenue = uservenues;
        if (this.login === undefined) {
          alert("Please log in");
          this.$router.push('/login');

        }
        if (this.$route.params.venueId === undefined) {
        } else {
          console.log(typeof (this.$route.params.venueId))
          var id = (this.$route.params.venueId).toString()
          this.id = id
          if (uservenues.includes(id)) {
          } else {
            alert("Cannot modifilied venue");
            this.$router.push("/")
          }
        }
      },
      getCategories: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/categories')
          .then(function (response) {
            this.venuenecater = response.data;
            var num = Object.assign({}, response.data, {"a": {"categoryId": 0, "categoryName": "All"}});
            this.categoryname = num;
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getphoto: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/venues/' + this.id)
          .then(function (response) {
            this.venueld = response.data.longDescription
            this.venueaddress = response.data.address
            this.venuecat.cat = response.data.category
            this.test = response.data
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      updatevenue: function () {
        if (this.venuename.length === 0 || this.venuename === 0 || this.venuesd === 0 ||
          this.venuecity === 0 || this.venuelat === 0 || this.venuelong === 0) {
          alert("Please enter all vneue details!")
        } else {
          this.$http.patch('http://127.0.0.1:4941/api/v1/venues/' + this.id, {
            venueName: this.venuename,
            categoryId: this.venuecat.cat.categoryId,
            city: this.city,
            shortDescription: this.venuesd,
            longDescription: this.venueld,
            address: this.venueaddress,
            latitude: Number(this.venuelat),
            longitude: Number(this.venuelong)
          }, {headers: {'X-Authorization': this.auth}})
            .then(function (response) {
              this.$router.push('/');
            }, function (error) {
              alert(error.statusText);
              this.error = true;
              this.errormessage = error.statusText;
            });
        }
      }
    },
    computed: {}
  }
</script>

<style scoped>

</style>
