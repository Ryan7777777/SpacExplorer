<template>
    <div>
      <div v-if="loginc === 'true'">
        <ul>
          <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
          <li><router-link :to="{name: 'me',params:{userId:id}}">Current user : {{username}}</router-link></li>
          <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
        </ul>

        <div  style="background-color: gray; padding-top: 10px; padding-bottom: 10px">
        <a style="font-size: 20px; font-family: 'Arial;">Add venue</a>
        </div>
        <br>
        <td>VenueName</td>
        <input v-model = "venuename" placeholder = "venuename"  type="text" >
        <td>CategoryId</td>
        <select v-model="category" style="width: 175px">
          <option v-for="cat in categoryname" v-bind:value="{cat}">{{cat.categoryName}}</option>
        </select>
        <td>City</td>
        <input v-model = "city" placeholder = "city"  type="text" >
        <td>Short Description</td>
        <input v-model = "shortdesscription" placeholder = "short decsription"  type="text" >
        <td>Long Description</td>
        <input v-model = "longdescription" placeholder = "long description"  type="text" >
        <td>address</td>
        <input v-model = "venueaddress" placeholder = "address"  type="text" >
        <td>latitude</td>
        <input v-model = "venunelatitude" placeholder = "latitude"  type="text" required>
        <td>longitude</td>
        <input v-model = "venuelogitude" placeholder = "longitude"  type="text" required>
        <br>
        <br>
        <button type = "button" class = "btn btn-primary" data-dismiss = "modal"
                v-on:click = "addvenue">
          add venue
        </button>
      </div>

    </div>
</template>

<script>
  export default {
    data() {
      return {
        loginc:false,
        auth:"",
        id:"",
        venuename:"",
        category:"",
        city:"",
        shortdesscription:"",
        longdescription:"",
        venueaddress:"",
        venunelatitude:"",
        venuelogitude:"",
        categoryname:[],
        username:""

      }
    },
    mounted: function () {
      this.getlogindata();
      this.getCategories();
    },
    methods: {
      getlogindata: function () {
        this.loginc = localStorage.login;
        this.auth = localStorage.auth;
        this.id = localStorage.userId;
        this.venuename === undefined;
        this.city === undefined;
        this.shortdesscription ===undefined;
        this.venueaddress === undefined;
        this.venuelogitude === undefined;
        this.venunelatitude === undefined;


        if (this.loginc === undefined) {
          alert("Please log in");
          this.$router.push('/login');
        }
        if(this.id !=undefined){
          this.getuser();
        }
      },
      getuser: function() {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
          });
      },
      addvenue: function () {
        var long = Number(this.venuelogitude);
        var lat = Number(this.venunelatitude);
        console.log(this.venuelogitude.length,11111)
        if ( this.venuelogitude.length === 0 || this.venunelatitude.length ===0){
          alert("Please enter all details!")
        } else {
        this.$http.post('http://127.0.0.1:4941/api/v1/venues', {
          venueName: this.venuename,
          categoryId: this.category.cat.categoryId,
          city: this.city,
          shortDescription: this.shortdesscription,
          longDescription: this.longdescription,
          address: this.venueaddress,
          latitude: long,
          longitude: lat
        }, {headers: {'X-Authorization': this.auth}})
          .then(function (response) {
            this.$router.push('/');
          }, function (error) {
            alert(error.statusText);
            this.error = true;
            this.errormessage = error.statusText;
          });
      }
      },
      getCategories: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/categories')
          .then(function (response) {
            var num = Object.assign({}, response.data, {});
            this.categoryname = num;
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      }
    },

    computed: {}
  }

</script>
<style>
  td{
    text-align: left;
    height: 20px;
  }
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  button{
    position: absolute;,
  bottom:0px;
  }
  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }
</style>

