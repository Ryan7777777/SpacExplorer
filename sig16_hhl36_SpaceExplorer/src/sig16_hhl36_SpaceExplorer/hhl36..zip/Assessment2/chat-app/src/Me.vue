<template>
    <div>
  <ul>
      <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
    <div v-if="$route.params.userId == searchid">
        <li><router-link :to="{name: 'me',params:{userId:id}}">Current user : {{username}}</router-link></li>
    </div>
        <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
      </ul>
      <br>
      <a>Username:</a>
      <a>{{username}}</a>
      <br>
      <a>Given name:</a>
      {{givenname}}
      <br>
      <a>Family name:</a>
      {{familyname}}<br>
      <div v-if="$route.params.userId != searchid"></div>
      <div v-else>
        <a>Email:</a>
        <a>{{emailaddress}}</a><br>
      <a>Password:</a>
      <a>{{password}}</a><br>
        <br>
        <button><router-link :to="{name: 'edituser',params:{userId:id}}" style='text-decoration:none; color: black'>Edit my profile</router-link></button>
        <br>
      </div>
      <img :src="src" alt="">
      <br>
        <button type = "button" class = "btn btn-primary" data-dismiss = "modal"
                v-on:click = "deletepic">
          Delete my profile picture
        </button>
      </div>
</template>

<script>
  export default {
    data() {
      return {
        username: "",
        givenname: "",
        familyname: "",
        emailaddress: "",
        password: "",
        error: false,
        errormessage: "",
        loginc: false,
        auth: "",
        id: "",
        searchid: "",
        src : "",
        type:""
      }
    },
    mounted: function () {
      this.getlogindata();
      this.getuser();
      this.getuserphoro();
    },
    methods: {
      getlogindata: function () {
        this.loginc = localStorage.login;
        this.auth = localStorage.auth;
        this.searchid = localStorage.userId;
        this.id = this.$route.params.userId;
        this.emailaddress = localStorage.email;
        this.password = localStorage.password;
      },
      getuser: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
            this.givenname = resopnse.data.givenName
            this.familyname = resopnse.data.familyName
          });
      },
      deletepic: function () {
        this.$http.delete("http://127.0.0.1:4941/api/v1/users/" + this.id + "/photo", {}, {headers: {'X-Authorization': this.auth}})
          .then(function (rep) {
            },
            function (error) {
              alert(error.statusText);
              this.$router.push('/');
            });
      },
      getuserphoro: function(){
        this.$http.get("http://127.0.0.1:4941/api/v1/users/"+this.id+"/photo",{responseType:'blob'})
          .then(function(rep){
              let reader = new FileReader();
              reader.readAsDataURL(rep.data);
              reader.onload = () => {
                this.src = reader.result;
              }
          },
          function(error){
            alert(error.statusText);
          })
      }
    },
    computed: {}
  }
</script>

<style scoped>
  td{
    text-align: left;
    height: 20px;
  }
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  button{
    position: absolute;,
  bottom:0px;
  }
  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }

</style>
