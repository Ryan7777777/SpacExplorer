<template>
  <div>
  <div v-if = "errorFlag" style = " color : red ; ">
    {{ error }}
  </div>
  <div v-if="login === 'true'">
    <ul>
      <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
      <li><router-link :to="{ name: 'addvenue' }" > Addedvenue </router-link></li>
      <li><router-link :to="{name: 'me',params:{userId:id}}">Current user : {{username}}</router-link></li>
      <li style="float:right"><router-link :to="{ name: 'logout' }" > Logout </router-link></li>
    </ul>
  </div>
  <div v-else>
    <ul>
      <li><router-link :to="{ name: 'home' }" > Home </router-link></li>
      <li><router-link :to="{ name: 'login' }" > Login </router-link></li>
      <li><router-link :to="{ name: 'register' }" > Register </router-link></li>
    </ul>
  </div>
  <table id="ven">
    <th style="width: 10%">Name:</th>
    <th style="width: 10%">Category:</th>
    <th style="width: 10%">Venues admin</th>
    <th style="width: 10%">City</th>
    <th style="width: 10%">Address</th>
    <th style="width: 10%">Added Date</th>
    <th style="width: 10%">Cost Rating</th>
    <th style="width: 10%">Star Rating</th>
    <th style="width: 10%">Description</th>

    <tr>
      <td>{{photos.venueName}}</td>
      <td>{{photos.category.categoryName}}</td>
      <td>{{photos.admin.username}}</td>
      <td>{{photos.city}}</td>
      <td>{{photos.address}}</td>
      <td>{{photos.dateAdded}}</td>
      <td>{{costslist[venues.modeCostRating].sign}}</td>
      <td>{{venues.meanStarRating}}</td>
      <td>
        <transition name="fade">
          <p v-if="longdesc">{{photos.longDescription}}</p>
          <p v-else>{{photos.shortDescription}}</p>
        </transition>
        <button v-on:click="longdesc = !longdesc">
          Expand/Lessen
        </button>
      </td>
    </tr>
  </table>
    <template v-if="venues.primaryPhoto == null">
      <a>{{'no photo for this venues'}}</a>
    </template>
    <template v-else>
      <span v-for="image in src">
               <img :src="image" alt="">
            </span>
    </template>

    <br>
  <button><router-link  :to="{name:'postreview',params:{venueId:$route.params.venueId}}"  style='text-decoration:none; color: black'>Write a review</router-link></button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        error: "",
        errorFlag: false,
        venues: [],
        cities: ["All", "None "],
        selected: 'All',
        categoryname:[],
        photos: [],
        length: "",
        search: "",
        selectcat: null,
        sortstar:"High",
        sortcost:null,
        costslist:[{"rate":0,"sign":"Free"},{"rate":1,"sign":"$"},{"rate":2,"sign":"$$"},{"rate":3,"sign":"$$$"},{"rate":4,"sign":"$$$$"}],
        costselect:"no select",
        starlist:[{"rate":1,"sign":"1"},{"rate":2,"sign":"2"},{"rate":3,"sign":"3"},{"rate":4,"sign":"4"},{"rate":5,"sign":"5"}],
        starselect:"no select",
        batches:1,
        bachesls:[],
        batchpage:"1",
        longdesc: false,
        login:false,
        auth:"",
        id:"",
        detial:[],
        username :"",
        src: [],
        venuesphotos: []
      }
    },
    mounted: function () {
      this.getlogindata();
      this.getCategories();
      this.getVenues();
      this.getphoto(this.$route.params.venueId);

    },
    methods: {
      getVenues: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/venues')
          .then(function (response) {
            for(var i=0; i<response.data.length; i++){
              if(response.data[i].venueId == this.$route.params.venueId){
                this.venues = response.data[i]
                if (this.venues.meanStarRating == null) {
                  this.venues.meanStarRating = 3
                }
                if (this.venues.modeCostRating === null) {
                  this.venues.modeCostRating = 0
                }
              }
            }
            this.uniqueVenue();

          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });
      },
      getlogindata: function () {
        this.login = localStorage.login
        this.auth = localStorage.auth
        this.id = localStorage.userId
        if (this.id != undefined) {
          this.getuser();
        }
      },
      getuser: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/users/' + this.id)
          .then(function (resopnse) {
            this.username = resopnse.data.username
          });
      },
      getCategories: function () {
        this.$http.get('http://127.0.0.1:4941/api/v1/categories')
          .then(function (response) {
            var num = Object.assign({}, response.data, {"a": {"categoryId": 0, "categoryName": "All"}});
            this.categoryname = num;
          }, function (error) {
            this.error = error;
            this.errorFlag = true;
          });

      },
      getphoto: function (id) {
          this.$http.get('http://127.0.0.1:4941/api/v1/venues/' +id)
            .then(function (response) {
              this.photos = response.data;
              this.photoarray();
            }, function (error) {
              this.error = error;
              this.errorFlag = true;
            });

      },
      uniqueVenue: function () {
        for (var i = 0; i < this.venues.length; i++) {
          if (this.cities.includes(this.venues[i].city)) {
          } else {
            this.cities.push(this.venues[i].city)
          }
        }
      },
      photo:function() {
        var id = this.venues.venueId;
       for(var i = 0 ;i<this.venuesphotos.length; i++)
        {
          this.$http.get("http://127.0.0.1:4941/api/v1/venues/" + id + "/photos/" + this.venuesphotos[i], {responseType: 'blob'})
            .then(function (rep) {
              let reader = new FileReader();
              reader.readAsDataURL(rep.data);
              reader.onload = () => {
                this.src.push(reader.result);
              }
            });
        }
       console.log(this.src)

      },
      photoarray: function() {
        for (var i = 0; i < this.photos.photos.length; i++) {
          if (!this.venuesphotos.includes(this.photos.photos[i].photoFilename)) {
            this.venuesphotos.push(this.photos.photos[i].photoFilename)
          }
        }
        this.photo()
      }
    },
    computed: {
      filteredcity: function () {
        var current_venues = this.venues;
        if(this.batchpage === "1"){}else{
          var lower = this.batchpage.batch *10 -10;
          if(this.batchpage.batch *10 > this.venues.length){
            var upper = this.venues.length;
          } else {
            var upper = this.batchpage.batch *10-1}
          current_venues = current_venues.slice(lower,upper);
        }
        if(this.selectcat == null || this.selectcat === "All" ) {
          current_venues = current_venues
        } else {
          var selectcat = this.selectcat;
          if (selectcat.cat.categoryId === 0) {
            current_venues = current_venues
          } else {
            current_venues = current_venues.filter(venue => venue.categoryId === selectcat.cat.categoryId)
          }
        }
        if (this.search === "") {}else{
          var search = this.search;
          current_venues = current_venues.filter(venue => venue.venueName.toLowerCase().includes(search.toLowerCase()))
        }if(this.selected === "All" || this.selected.city == 'All'){}else{
          var selectcity = this.selected.city;
          current_venues = current_venues .filter(venue => venue.city === selectcity)
        }
        if (this.sortstar == "High"){
          current_venues = current_venues.slice().sort((a, b) => (a.meanStarRating) + (b.meanStarRating))
        }else{
          current_venues = current_venues.slice().sort((a, b) => (a.meanStarRating) - (b.meanStarRating))
        }
        if (this.sortcost == null) {}else if(this.sortcost == "High"){
          current_venues = current_venues.slice().sort((a, b) => (a.modeCostRating) + (b.modeCostRating))
        } else {
          current_venues = current_venues.slice().sort((a, b) => (a.modeCostRating) - (b.modeCostRating))
        }
        if(this.costselect === "no select"){}else{
          current_venues = current_venues.filter(venue =>   this.costselect.cost.rate <= venue.modeCostRating)
        }
        if(this.starselect === "no select"){}else{
          current_venues = current_venues.filter(venue => venue.meanStarRating >= this.starselect.cost.rate)
        }
        return current_venues;
      }
    }
  }
</script>

<style scoped>
  c{
    float:right;
  }
  table {
    border-collapse: collapse;
    table-layout: fixed;
    font-falimy: Arial;
    wdith: 100%
  }
  table th{

    height: 10px;
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #8C8888;
    color: white;
  }

  img{
    width: 100%;
    height:auto;
    display: block
  }
  td{
    text-align: left;
    height: 20px;
  }
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
  }
  button{
    position: absolute;,
  bottom:0px;
  }
  li {
    float: left;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }
  li a:hover {
    background-color: #222;
  }
  button {
    width:150px;
    heihgt:100px;
  }
  th{
    padding-left: 40px;
  }
  td{
    padding-top: 10px;
    padding-bottom: 5px;
    padding-left: 40px;
  }
img{
  width:20%;
  height:auto;
}
</style>
