import Vue from "vue";
import VueRouter from "vue-router";
import VueResource from "vue-resource";
import Home from "./Home.vue";
import Myvenune from "./Myvenune.vue";
import UpdateVenune from "./UpdateVenue.vue";
import App from './App.vue';
import Register from "./Register.vue";
import Me from "./Me.vue";
import Edituser from "./EditUser.vue";
import PostReview from "./PostReview.vue";
import Review from "./Review.vue";
import Login from "./Login.vue";
import Logout from "./Logout.vue";
import AddVenue from "./AddVenue.vue";
import View from "./view.vue";



Vue.use(VueRouter);
Vue.use(VueResource);

Vue . http . options . emulateJSON = false;
Vue.config.productionTip = false;

const routes = [
  {
    path:"/",
    name:"home",
    component: Home
  },
  {
    path:"/venue/:venueId",
    name:"venue",
    component: View
  },
  {
    path:"/venueadmin",
    name:"venueadmin",
    component: Myvenune
  },
  {
    path:"/updatevenue/:venueId",
    name: "updatevenue",
    component:UpdateVenune
  },
  {
    path:"/register",
    name:"register",
    component: Register
  },
  {
    path:"/me/:userId",
    name:"me",
    component:Me
  },
  {
    path:"/edituser/:userId",
    name:"edituser",
    component:Edituser
  },
  {
    path:"/postreview/:venueId",
    name:"postreview",
    component: PostReview
  },
  {
    path: "/reviews/:venueId",
    name: "review",
    component: Review
  },
  {
    path:"/login",
    name:"login",
    component: Login
  },
  {
    path:"/logout",
    name:"logout",
    component:Logout
  },
  {
    path:"/addvenue",
    name:"addvenue",
    component: AddVenue
  }
];

const router = new VueRouter ({
  routes : routes,
  mode : 'history'
});

new Vue ({
  el : '#app',
  router: router,
  render : h => h ( App)
});

